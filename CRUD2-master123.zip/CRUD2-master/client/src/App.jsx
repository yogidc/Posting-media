import { useState, useEffect } from "react";
import axios from "axios";
import "./App.css";

function App() {
  const [posts, setPosts] = useState([]);
  const [author, setAuthor] = useState("");
  const [text, setText] = useState("");
  const [editId, setEditId] = useState(null);

  const API_URL = "http://localhost:3000/posts";

  // Fetch all posts from the server
  const fetchPosts = async () => {
    try {
      const response = await axios.get(API_URL);
      setPosts(response.data);
    } catch (error) {
      console.error("Error fetching posts:", error);
    }
  };

  useEffect(() => {
    fetchPosts();
  }, []);

  // Create or update a post
  const handleSubmit = async (e) => {
    e.preventDefault();

    if (editId) {
      // Update existing post
      try {
        await axios.put(`${API_URL}/${editId}`, { text });
        alert("Post updated successfully!");
        setEditId(null);
        setText("");
        fetchPosts();
      } catch (error) {
        console.error("Error updating post:", error);
      }
    } else {
      // Create new post
      try {
        await axios.post(API_URL, { author, text });
        alert("Post created successfully!");
        setAuthor("");
        setText("");
        fetchPosts();
      } catch (error) {
        console.error("Error creating post:", error);
      }
    }
  };

  // Delete a post
  const deletePost = async (id) => {
    try {
      await axios.delete(`${API_URL}/${id}`);
      alert("Post deleted successfully!");
      fetchPosts();
    } catch (error) {
      console.error("Error deleting post:", error);
    }
  };

  // Start editing a post
  const startEditing = (post) => {
    setEditId(post.id);
    setText(post.text);
  };

  return (
    <div className="App">
      <h1>Posting Media</h1>

      {/* Form to create or edit a post */}
      <form onSubmit={handleSubmit}>
        {!editId && (
          <div>
            <label>Author:</label>
            <input
              type="text"
              placeholder="Enter author name"
              value={author}
              onChange={(e) => setAuthor(e.target.value)}
              required
            />
          </div>
        )}
        <div>
          <label>Post Thoughts:</label>
          <textarea
            placeholder="Enter your post"
            value={text}
            onChange={(e) => setText(e.target.value)}
            required
          />
        </div>
        <button type="submit">{editId ? "Update Post" : "Create Post"}</button>
      </form>

      <hr />

      {/* Display all posts */}
      <h2>All Posts</h2>
      {posts.length === 0 ? (
        <p>No posts available.</p>
      ) : (
        <ul>
          {posts.map((post) => (
            <li key={post.id} className="post">
              <p>
                <strong>Author:</strong> {post.author}
              </p>
              <p>
                <strong>Text:</strong> {post.text}
              </p>
              <p>
                <strong>Posted on:</strong>{" "}
                {new Date(post.date).toLocaleString()}
              </p>
              <button onClick={() => startEditing(post)}>Edit</button>
              <button onClick={() => deletePost(post.id)}>Delete</button>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}

export default App;
